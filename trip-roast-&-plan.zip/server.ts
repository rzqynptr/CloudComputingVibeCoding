import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const PORT = 3000;
const app = express();

app.use(express.json());

// Initialize GoogleGenAI client on the server side
// Note: User-Agent is set to 'aistudio-build' for tracking
const getGenAIClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not defined in environment variables.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    }
  });
};

// API Endpoint to process Trip Roast & Plan
app.post("/api/roast-and-plan", async (req, res) => {
  try {
    const { destinasi, durasi, jumlahOrang, budget, cerita } = req.body;

    if (!destinasi || !durasi || !jumlahOrang || !budget || !cerita) {
      return res.status(400).json({ error: "Semua form field wajib diisi!" });
    }

    const ai = getGenAIClient();

    const prompt = `
      Roast rencana liburan saya dan buatkan itinerary yang realistis, detail, dan jauh lebih baik!
      
      Informasi Rencana Liburan:
      - Destinasi: ${destinasi}
      - Durasi: ${durasi}
      - Jumlah Orang: ${jumlahOrang}
      - Budget: ${budget}
      - Cerita Rencana Liburan: ${cerita}

      Lakukan roasting dengan gaya bahasa Indonesia gaul (casual, humoris, sedikit sarkas tapi ramah dan menghibur, khas tongkrongan anak muda Jakarta).
      Tunjukkan kekurangan, keanehan, atau ketidakrealistisan dari rencana liburan saya (misal budget terlalu mepet, durasi terlalu singkat/lama, destinasi kurang cocok untuk tipe rombongan/orang, atau keganjilan pada cerita rencana liburan saya).
      Berikan maksimal 4-5 poin roasting yang witty, tajam tapi kocak. Diakhiri dengan 1 kalimat penyemangat pendek yang santai.

      Setelah selesai dengan roasting, susun itinerary baru yang jauh lebih taktis, masuk akal, aman, dan memuaskan.
      Persyaratan itinerary:
      1. Tersusun detail per hari dengan jam kegiatan terstruktur (misal 08:00 - 10:00: Aktivitas).
      2. Berikan estimasi budget per pos pengeluaran (misal: Komunikasi/Internet, Kuliner, Transportasi Lokal, Tiket Masuk, Akomodasi).
      3. Berikan tepat 3 tips praktis perjalanan (practical tips) yang sangat berguna untuk destinasi tersebut.
    `;

    // Prompt Gemini with Response Mime Type and Schema
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "Anda adalah asisten travel planner sekaligus standup comedian yang ahli merencanakan perjalanan keren dan lihai meroasting rencana liburan orang secara kocak, witty, hangat, dan menghibur. Gunakan bahasa Indonesia kasual, gaul, dan santai.",
        temperature: 1.0,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            roast: {
              type: Type.OBJECT,
              properties: {
                wittyPoints: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "4 sampai 5 poin roasting yang sangat jenaka, tajam tapi kocak, dan menghibur tentang rencana liburan user menggunakan bahasa Indonesia gaul."
                },
                encouragement: {
                  type: Type.STRING,
                  description: "1 kalimat penyemangat pendek yang santai dan hangat di akhir roasting."
                }
              },
              required: ["wittyPoints", "encouragement"]
            },
            itinerary: {
              type: Type.OBJECT,
              properties: {
                days: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      dayNumber: { type: Type.INTEGER },
                      title: { type: Type.STRING, description: "Judul tema hari tersebut (misalnya 'Eksplorasi Kota & Surga Kuliner')" },
                      activities: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            time: { type: Type.STRING, description: "Jam kegiatan, misal '08:00 - 10:30'" },
                            activity: { type: Type.STRING, description: "Detail kegiatan yang menarik" },
                            estimatedCost: { type: Type.STRING, description: "Estimasi biaya, contoh 'Rp 50.000' atau 'Gratis'" }
                          },
                          required: ["time", "activity", "estimatedCost"]
                        }
                      }
                    },
                    required: ["dayNumber", "title", "activities"]
                  }
                },
                budgetBreakdown: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      category: { type: Type.STRING, description: "Pos pengeluaran, misal 'Akomodasi', 'Aktivitas & Tiket', 'Transportasi', 'Konsumsi', 'Mendadak/Cadangan'" },
                      amount: { type: Type.STRING, description: "Saran alokasi budget" },
                      note: { type: Type.STRING, description: "Catatan singkat taktis" }
                    },
                    required: ["category", "amount", "note"]
                  }
                },
                practicalTips: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Tepat 3 tips praktis perjalanan yang sangat berharga dan nyata untuk destinasi tersebut."
                }
              },
              required: ["days", "budgetBreakdown", "practicalTips"]
            }
          },
          required: ["roast", "itinerary"]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      return res.status(500).json({ error: "Gagal memproses hasil dari AI" });
    }

    const resultJson = JSON.parse(textOutput);
    return res.json(resultJson);

  } catch (error: any) {
    console.error("Error in /api/roast-and-plan:", error);
    return res.status(500).json({
      error: error.message || "Terjadi kesalahan internal pada server."
    });
  }
});

// Configure Vite middleware or static serving
const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
};

startServer().catch((err) => {
  console.error("Gagal memulai server:", err);
});
