import { useState, useRef, FormEvent } from "react";
import Header from "./components/Header";
import ExampleTrips from "./components/ExampleTrips";
import TripForm from "./components/TripForm";
import RoastCard from "./components/RoastCard";
import ItineraryCard from "./components/ItineraryCard";
import { TripFormData, TripRoastAndPlanResponse } from "./types";
import { Sparkles, Trash2, RotateCcw, AlertTriangle, ArrowRight, Flame, MapPin } from "lucide-react";

export default function App() {
  const [formData, setFormData] = useState<TripFormData>({
    destinasi: "",
    durasi: "",
    jumlahOrang: "",
    budget: "",
    cerita: "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<TripRoastAndPlanResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const resultRef = useRef<HTMLDivElement>(null);

  const handleTemplateSelect = (data: TripFormData) => {
    setFormData(data);
    setError(null);
    // Smooth scroll to form
    window.scrollTo({
      top: 300,
      behavior: "smooth"
    });
  };

  const handleReset = () => {
    setFormData({
      destinasi: "",
      durasi: "",
      jumlahOrang: "",
      budget: "",
      cerita: "",
    });
    setResult(null);
    setError(null);
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await fetch("/api/roast-and-plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Gagal menghubungi server untuk meroasting perjalananmu.");
      }

      const data: TripRoastAndPlanResponse = await response.json();
      setResult(data);

      // Scroll smoothly to results
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Oops! Server ngadat waktu meroasting rencana kamu. Coba lagi, ya!");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pb-20 relative px-4 sm:px-6 lg:px-8 selection:bg-orange-200">
      {/* Background aesthetics pattern */}
      <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-orange-50/50 via-emerald-50/30 to-transparent -z-10"></div>
      
      <div className="max-w-6xl mx-auto">
        <Header />

        {/* Display template selectors ONLY if there's no result or we are not loading */}
        {!result && !isLoading && (
          <ExampleTrips onSelect={handleTemplateSelect} />
        )}

        <div className="mt-8">
          {/* If there is no result, show the beautiful form */}
          {!result && (
            <TripForm
              formData={formData}
              setFormData={setFormData}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}

          {/* Error Message display with a crisp style */}
          {error && (
            <div className="w-full max-w-2xl mx-auto mt-6 p-5 bg-red-50 border-2 border-red-200 rounded-2xl flex items-start gap-4">
              <AlertTriangle className="text-red-500 shrink-0 mt-0.5 animate-bounce" size={20} />
              <div>
                <h4 className="font-display font-bold text-sm text-red-900">Yah, Error Cuy!</h4>
                <p className="text-xs text-red-800 mt-1 font-medium leading-relaxed">{error}</p>
              </div>
            </div>
          )}

          {/* Loading status details overlay (very immersive) */}
          {isLoading && (
            <div className="w-full max-w-2xl mx-auto mt-12 text-center p-10 bg-white border border-slate-100 rounded-3xl shadow-xl flex flex-col items-center justify-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-400 via-pink-400 to-emerald-400 animate-pulse"></div>
              
              <div className="relative mb-6">
                <div className="w-16 h-16 rounded-full border-4 border-orange-100 border-t-orange-500 animate-spin flex items-center justify-center"></div>
                <Flame className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-orange-500 animate-pulse" size={24} />
              </div>

              <h3 className="font-display font-bold text-lg text-slate-800 mb-2">
                Memanggil Agen Satir & Ahli Travel...
              </h3>
              <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed italic">
                "AI sedang membaca ceritamu, mengecek harga tiket terbaru, membandingkan mimpimu dengan kenyataan saldo tabungan, dan bersiap-siap melakukan roasting legendaris..."
              </p>

              <div className="mt-6 flex flex-wrap justify-center gap-3 text-xs font-semibold text-slate-500">
                <span className="bg-slate-100 px-3 py-1.5 rounded-full">📍 {formData.destinasi || "Tempat Rahasia"}</span>
                <span className="bg-slate-100 px-3 py-1.5 rounded-full">⏱️ {formData.durasi || "Tanpa Batas"}</span>
                <span className="bg-slate-100 px-3 py-1.5 rounded-full">💰 Budget {formData.budget || "Mepet"}</span>
              </div>
            </div>
          )}

          {/* Results section */}
          {result && (
            <div ref={resultRef} className="space-y-10 max-w-5xl mx-auto mt-6 animate-fade-in">
              
              {/* Review criteria badge */}
              <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-8 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4 border border-slate-800">
                <div className="flex items-center gap-4 text-center sm:text-left">
                  <span className="p-3 bg-slate-800 text-amber-500 rounded-2xl shrink-0 hidden sm:block">
                    <Sparkles size={24} className="animate-spin-slow" />
                  </span>
                  <div>
                    <h3 className="font-display font-extrabold text-lg sm:text-xl tracking-tight">
                      Hasil Analisis Liburanmu Siap! 🎉
                    </h3>
                    <p className="text-xs text-slate-400 font-medium mt-0.5">
                      Rencana perjalanan ke <strong className="text-white bg-slate-800 px-2.5 py-0.5 rounded">{formData.destinasi}</strong> telah diproses sepenuhnya.
                    </p>
                  </div>
                </div>

                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={handleReset}
                    className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl flex items-center gap-2 transition-all cursor-pointer border border-slate-700 active:scale-95"
                  >
                    <RotateCcw size={14} />
                    <span>Rancang Baru</span>
                  </button>
                </div>
              </div>

              {/* Form details synopsis */}
              <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-xs font-bold text-slate-400 block uppercase mb-0.5">📍 Destinasi</span>
                  <p className="font-bold text-slate-800">{formData.destinasi}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 block uppercase mb-0.5">⏱️ Durasi</span>
                  <p className="font-bold text-slate-800">{formData.durasi}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 block uppercase mb-0.5">👥 Anggota</span>
                  <p className="font-bold text-slate-800">{formData.jumlahOrang}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-400 block uppercase mb-0.5">💰 Budget Maks</span>
                  <p className="font-bold text-slate-800">{formData.budget}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Roast Result Portion - Take 5 columns on large screen */}
                <div className="lg:col-span-5 h-full">
                  <RoastCard roast={result.roast} />
                </div>

                {/* Itinerary Result Portion - Take 7 columns on large screen */}
                <div className="lg:col-span-7 h-full">
                  <ItineraryCard itinerary={result.itinerary} />
                </div>
                
              </div>

              {/* Reset footer button */}
              <div className="pt-6 flex justify-center">
                <button
                  onClick={handleReset}
                  className="px-8 py-4 bg-gradient-to-r from-slate-900 to-slate-800 text-white font-bold text-sm tracking-wide rounded-2xl inline-flex items-center gap-2.5 hover:shadow-lg transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer border border-transparent shadow hover:shadow-slate-900/10 active:scale-95"
                >
                  <RotateCcw size={16} />
                  <span>Coba Lagi & Iseng Buat Skenario Lain!</span>
                </button>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
}
