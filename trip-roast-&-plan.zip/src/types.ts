export interface Activity {
  time: string;
  activity: string;
  estimatedCost: string;
}

export interface DayItinerary {
  dayNumber: number;
  title: string;
  activities: Activity[];
}

export interface BudgetCategory {
  category: string;
  amount: string;
  note: string;
}

export interface RoastResult {
  wittyPoints: string[];
  encouragement: string;
}

export interface ItineraryResult {
  days: DayItinerary[];
  budgetBreakdown: BudgetCategory[];
  practicalTips: string[];
}

export interface TripRoastAndPlanResponse {
  roast: RoastResult;
  itinerary: ItineraryResult;
}

export interface TripFormData {
  destinasi: string;
  durasi: string;
  jumlahOrang: string;
  budget: string;
  cerita: string;
}
