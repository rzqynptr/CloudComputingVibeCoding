import { CalendarDays, DollarSign, Lightbulb, CheckCircle, Navigation } from "lucide-react";
import { ItineraryResult } from "../types";

interface ItineraryCardProps {
  itinerary: ItineraryResult;
}

export default function ItineraryCard({ itinerary }: ItineraryCardProps) {
  return (
    <div className="bg-gradient-to-br from-emerald-50 to-blue-50 border border-emerald-200 rounded-3xl p-6 sm:p-10 shadow-lg relative overflow-hidden">
      {/* Decorative ambient background blur lights */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-emerald-200/40 rounded-full filter blur-xl"></div>
      <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-blue-200/40 rounded-full filter blur-xl"></div>

      <div className="relative">
        <div className="flex items-center gap-3 pb-4 mb-6 border-b border-emerald-200/50">
          <span className="p-2.5 bg-emerald-100 text-emerald-600 rounded-2xl">
            <CalendarDays size={24} className="stroke-[2]" />
          </span>
          <div>
            <h3 className="font-display font-extrabold text-xl tracking-tight text-emerald-950">
              BAGIAN 2 — ITINERARY TAKTIS & REALISTIS
            </h3>
            <p className="text-xs font-semibold text-emerald-800 uppercase tracking-widest mt-0.5">
              Rencana Perjalanan Ideal Rekomendasi AI 🗺️
            </p>
          </div>
        </div>

        {/* List of Days */}
        <div className="space-y-8 mb-8">
          {itinerary.days.map((day, idx) => (
            <div key={idx} className="relative pl-6 border-l-2 border-emerald-300/60 last:border-0 pb-1">
              {/* Timeline marker node */}
              <div className="absolute -left-2 top-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-emerald-50 shadow-md"></div>
              
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl border border-emerald-200/30 shadow-sm p-4 sm:p-6 transition-all hover:shadow">
                <span className="inline-block text-xs font-bold text-emerald-700 bg-emerald-100/60 px-2.5 py-0.5 rounded-full mb-3 uppercase tracking-wider">
                  Hari Ke-{day.dayNumber}
                </span>
                <h4 className="font-display font-bold text-lg text-slate-800 mb-4">
                  {day.title}
                </h4>

                {/* Day's Activities */}
                <div className="space-y-3">
                  {day.activities.map((act, aIdx) => (
                    <div key={aIdx} className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 p-3 bg-slate-50/60 rounded-xl border border-slate-100">
                      <div className="flex gap-2.5">
                        <span className="font-mono text-xs font-semibold bg-emerald-100 text-emerald-800 shrink-0 px-2.5 py-1 rounded-lg self-start">
                          {act.time}
                        </span>
                        <p className="text-sm font-medium text-slate-700 leading-relaxed pt-0.5">
                          {act.activity}
                        </p>
                      </div>
                      <span className="text-xs font-bold text-slate-500 bg-white border border-slate-200/60 px-2.5 py-1 rounded-lg self-start sm:self-center shrink-0">
                        Biaya: {act.estimatedCost}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Budget Allocation Breakdown */}
        <div className="mb-8">
          <h4 className="font-display font-bold text-base text-slate-800 mb-4 flex items-center gap-2">
            <DollarSign size={18} className="text-emerald-600 bg-emerald-100 rounded-lg p-0.5" />
            Alokasi Budget Sesuai Pos Pengeluaran
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {itinerary.budgetBreakdown.map((budget, bIdx) => (
              <div key={bIdx} className="bg-white/80 backdrop-blur-sm p-4.5 rounded-2xl border border-emerald-200/30 shadow-sm">
                <p className="text-xs font-bold text-emerald-800 bg-emerald-100/50 inline-block px-2 py-0.5 rounded-lg uppercase tracking-wide mb-2">
                  {budget.category}
                </p>
                <p className="text-base font-extrabold text-slate-800 mb-1.5">
                  {budget.amount}
                </p>
                <p className="text-xs text-slate-600 leading-relaxed italic">
                  {budget.note}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Practical tips */}
        <div className="bg-white/90 backdrop-blur border border-emerald-200/50 rounded-2xl p-6 shadow-inner">
          <h4 className="font-display font-semibold text-base text-slate-800 mb-4 flex items-center gap-2">
            <Lightbulb size={20} className="text-amber-500" />
            3 Tips Praktis Perjalanan
          </h4>
          <ul className="space-y-3">
            {itinerary.practicalTips.slice(0, 3).map((tip, tIdx) => (
              <li key={tIdx} className="flex gap-3 text-sm text-slate-600 font-medium leading-relaxed">
                <CheckCircle size={18} className="text-emerald-500 shrink-0 mt-0.5" />
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
