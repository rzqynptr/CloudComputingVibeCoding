import { Flame, Bomb, Skull, HeartHandshake, Smile } from "lucide-react";
import { RoastResult } from "../types";

interface RoastCardProps {
  roast: RoastResult;
}

export default function RoastCard({ roast }: RoastCardProps) {
  const wittyIcons = [
    <Flame size={18} className="text-red-500 animate-pulse" />,
    <Bomb size={18} className="text-orange-500" />,
    <Skull size={18} className="text-pink-600" />,
    <Smile size={18} className="text-amber-500" />,
  ];

  return (
    <div className="bg-gradient-to-br from-orange-50 to-pink-50 border border-orange-200 rounded-3xl p-6 sm:p-10 shadow-lg relative overflow-hidden">
      {/* Decorative ambient background blur lights */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-orange-200/50 rounded-full filter blur-xl"></div>
      <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-pink-200/50 rounded-full filter blur-xl"></div>

      <div className="relative">
        <div className="flex items-center gap-3 pb-4 mb-6 border-b border-orange-200/50">
          <span className="p-2.5 bg-orange-100 text-orange-600 rounded-2xl">
            <Flame size={24} className="fill-orange-500 stroke-[2]" />
          </span>
          <div>
            <h3 className="font-display font-extrabold text-xl tracking-tight text-orange-950">
              BAGIAN 1 — ROASTING TAJAM GAUL
            </h3>
            <p className="text-xs font-semibold text-orange-800 uppercase tracking-widest mt-0.5">
              Siapkan Mental Sebelum Baca! 🔥
            </p>
          </div>
        </div>

        {/* Roasting points list */}
        <div className="space-y-4">
          {roast.wittyPoints.map((point, idx) => (
            <div
              key={idx}
              className="flex items-start gap-4 p-4 bg-white/80 backdrop-blur-sm rounded-2xl border border-orange-200/30 shadow-sm hover:shadow transition-shadow"
            >
              <div className="p-2 bg-orange-100/50 rounded-xl flex-shrink-0 mt-0.5">
                {wittyIcons[idx % wittyIcons.length]}
              </div>
              <div>
                <p className="text-sm font-medium text-slate-800 leading-relaxed">
                  {point}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Concluding encouragement */}
        <div className="mt-8 p-5 bg-gradient-to-r from-orange-100 to-amber-100 rounded-2xl border border-orange-200/60 shadow-inner flex items-center gap-4">
          <HeartHandshake className="text-orange-600 flex-shrink-0" size={24} />
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-orange-900/70 mb-0.5">
              Pesan Penyemangat Tulus
            </p>
            <p className="text-sm font-semibold text-orange-950 italic leading-relaxed">
              "{roast.encouragement}"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
