import { Compass, Flame, Sparkles } from "lucide-react";

export default function Header() {
  return (
    <header className="py-10 text-center select-none">
      <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-4 text-xs font-semibold tracking-wider uppercase bg-orange-100 text-orange-800 rounded-full border border-orange-200">
        <Sparkles size={12} className="text-orange-500 animate-pulse" />
        <span>Edisi Liburan Jujur & Taktis</span>
      </div>
      
      <h1 className="font-display font-bold text-4xl sm:text-6xl tracking-tight text-slate-900 flex flex-wrap justify-center items-center gap-x-3 gap-y-1">
        <span>Trip</span> 
        <span className="relative inline-block text-orange-600 font-extrabold strike-through">
          Roast
          <span className="absolute -top-1 -right-4 text-orange-400 rotate-12">
            <Flame size={20} className="fill-orange-400" />
          </span>
        </span>
        <span className="text-slate-400 font-light">&</span>
        <span className="text-emerald-600 relative inline-block">
          Plan
          <span className="absolute -bottom-1 left-0 w-full h-1 bg-emerald-500/20 rounded"></span>
        </span>
      </h1>
      
      <p className="mt-4 text-slate-600 max-w-xl mx-auto px-4 text-base sm:text-lg leading-relaxed">
        Ketik detail liburan impianmu, hadapi <strong className="text-orange-600">roasting jujur</strong> yang bikin sadar diri, dan dapatkan <strong className="text-emerald-600">itinerary taktis</strong> yang jauh lebih taktis & realistis!
      </p>
    </header>
  );
}
