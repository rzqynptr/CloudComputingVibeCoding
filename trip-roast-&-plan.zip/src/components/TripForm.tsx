import React from "react";
import { MapPin, Clock, Users, Landmark, AlertCircle, FileText, SendHorizontal } from "lucide-react";
import { TripFormData } from "../types";

interface TripFormProps {
  formData: TripFormData;
  setFormData: React.Dispatch<React.SetStateAction<TripFormData>>;
  onSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
}

export default function TripForm({ formData, setFormData, onSubmit, isLoading }: TripFormProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white border border-slate-100 rounded-3xl shadow-xl p-6 sm:p-10 transition-all">
      <div className="flex items-center gap-3 pb-6 mb-6 border-b border-slate-100">
        <div className="p-3 bg-orange-50 text-orange-600 rounded-2xl">
          <AlertCircle size={24} className="stroke-[2]" />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-slate-800">
            Detail Rencana Liburanmu
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Isi dengan jujur biar roastingnya makin presisi & itinerary-nya makin realistis!
          </p>
        </div>
      </div>

      <form onSubmit={onSubmit} className="space-y-6">
        {/* Destinasi & Durasi */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <MapPin size={14} className="text-slate-400" />
              Destinasi Liburan
            </label>
            <input
              type="text"
              name="destinasi"
              value={formData.destinasi}
              onChange={handleChange}
              disabled={isLoading}
              required
              placeholder="Contoh: Paris, Swiss, Labuan Bajo"
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-medium text-slate-800 text-sm outline-none transition-all disabled:opacity-50"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Clock size={14} className="text-slate-400" />
              Durasi Perjalanan
            </label>
            <input
              type="text"
              name="durasi"
              value={formData.durasi}
              onChange={handleChange}
              disabled={isLoading}
              required
              placeholder="Contoh: 3 Hari, 1 Minggu"
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-medium text-slate-800 text-sm outline-none transition-all disabled:opacity-50"
            />
          </div>
        </div>

        {/* Jumlah Orang & Budget */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Users size={14} className="text-slate-400" />
              Jumlah Orang
            </label>
            <input
              type="text"
              name="jumlahOrang"
              value={formData.jumlahOrang}
              onChange={handleChange}
              disabled={isLoading}
              required
              placeholder="Contoh: 1 Orang, Rombongan RT (20)"
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-medium text-slate-800 text-sm outline-none transition-all disabled:opacity-50"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Landmark size={14} className="text-slate-400" />
              Budget Total (Maksimal)
            </label>
            <input
              type="text"
              name="budget"
              value={formData.budget}
              onChange={handleChange}
              disabled={isLoading}
              required
              placeholder="Contoh: Rp 3 Juta, Rp 10 Juta all-in"
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-medium text-slate-800 text-sm outline-none transition-all disabled:opacity-50"
            />
          </div>
        </div>

        {/* Cerita Rencana Liburan */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <FileText size={14} className="text-slate-400" />
            Cerita Rencana Liburan Bebas
          </label>
          <textarea
            name="cerita"
            value={formData.cerita}
            onChange={handleChange}
            disabled={isLoading}
            required
            rows={4}
            placeholder="Ketik rencana gilamu di sini... misalnya: 'Mau nginap di resort mewah di Swiss terus makannya harus mie instan bawa dari rumah biar hemat budget.'"
            className="w-full px-4 py-3 rounded-3xl bg-slate-50 border border-slate-200 focus:bg-white focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 font-medium text-slate-800 text-sm leading-relaxed outline-none transition-all resize-none disabled:opacity-50"
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-4 text-sm font-semibold tracking-wide text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 rounded-2xl shadow-lg hover:shadow-xl shadow-orange-500/20 hover:shadow-orange-500/30 transition-all flex items-center justify-center gap-2 transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-75 disabled:pointer-events-none cursor-pointer"
        >
          {isLoading ? (
            <div className="flex items-center gap-2.5">
              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              <span>Sedang Menganalisis & Meroasting...</span>
            </div>
          ) : (
            <>
              <SendHorizontal size={16} />
              <span>Analisis & Roast Rencanaku Sekarang!</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
