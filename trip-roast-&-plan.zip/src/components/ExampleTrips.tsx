import { Sparkles, MessageCircleWarning, Users, Wallet } from "lucide-react";
import { TripFormData } from "../types";

interface ExampleTripsProps {
  onSelect: (data: TripFormData) => void;
}

export default function ExampleTrips({ onSelect }: ExampleTripsProps) {
  const templates = [
    {
      title: "✈️ Halo Swiss Impian, Bye Isi Dompet",
      destinasi: "Swiss (Zwitzerland)",
      durasi: "7 Hari 6 Malam",
      jumlahOrang: "1 Orang",
      budget: "Rp 5.000.000 (sudah termasuk tiket pesawat PP)",
      cerita: "Mau keliling danau Jenewa, naik kereta panoramic bernina express, belanja coklat premium tiap jam, dan tidur di resort kaca estetik biar bisa pamer di TikTok.",
      color: "border-amber-200 bg-amber-50/70 hover:bg-amber-100/50",
      iconColor: "text-amber-600 bg-amber-100",
      badge: "Kategori: Mustahil bin Halusinasi"
    },
    {
      title: "👨‍👩- Keluarga Besar Healing Totalitas",
      destinasi: "Bali",
      durasi: "5 Hari 4 Malam",
      jumlahOrang: "12 Orang (Termasuk 4 Balita & 2 Lansia)",
      budget: "Rp 10.000.000 (All-In sekeluarga)",
      cerita: "Mau sewa villa privat pool bintang 5 tepi pantai Seminyak, sewa 2 mobil Alphard biar estetik, makan malam seafood mewah di Jimbaran tiap hari, dan main watersport di Tanjung Benoa.",
      color: "border-pink-200 bg-pink-50/70 hover:bg-pink-100/50",
      iconColor: "text-pink-600 bg-pink-100",
      badge: "Kategori: Siksaan Berkedok Liburan"
    },
    {
      title: "🏍️ Backpacker Lombok Supra Bapack",
      destinasi: "Lombok",
      durasi: "3 Hari 2 Malam",
      jumlahOrang: "2 Orang",
      budget: "Rp 1.500.000",
      cerita: "Hari ke-1 mau daki puncak Rinjani, hari ke-2 mau diving mewah di Gili Trawangan, hari ke-3 mau keliling sirkuit Mandalika naik motor sewaan Supra X bapak-bapak yang sering mogok.",
      color: "border-blue-200 bg-blue-50/70 hover:bg-blue-100/50",
      iconColor: "text-blue-600 bg-blue-100",
      badge: "Kategori: Kerja Rodi Ekstrem"
    }
  ];

  return (
    <div className="mt-2 mb-10">
      <div className="text-center mb-6">
        <h3 className="font-display font-medium text-lg text-slate-700 inline-flex items-center gap-2">
          <Sparkles size={16} className="text-amber-500" />
          Mager ngetik? Klik salah satu skenario kocak ini:
        </h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 px-4 max-w-5xl mx-auto">
        {templates.map((tpl, i) => (
          <button
            key={i}
            onClick={() => onSelect({
              destinasi: tpl.destinasi,
              durasi: tpl.durasi,
              jumlahOrang: tpl.jumlahOrang,
              budget: tpl.budget,
              cerita: tpl.cerita
            })}
            className={`flex flex-col text-left p-5 rounded-2xl border transition-all duration-300 transform hover:-translate-y-1 active:translate-y-0 cursor-pointer shadow-sm hover:shadow-md ${tpl.color}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider bg-white px-2 py-0.5 rounded-full border border-slate-100">
                {tpl.badge}
              </span>
            </div>
            
            <h4 className="font-display font-semibold text-slate-800 text-base mb-2">
              {tpl.title}
            </h4>
            
            <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-slate-500 mb-3 font-medium">
              <span className="flex items-center gap-1">📍 {tpl.destinasi}</span>
              <span className="flex items-center gap-1">⏱️ {tpl.durasi}</span>
              <span className="flex items-center gap-1">💰 {tpl.budget}</span>
            </div>
            
            <p className="text-xs text-slate-600 line-clamp-3 bg-white/60 p-2.5 rounded-xl italic border border-slate-100/50 mt-auto">
              "{tpl.cerita}"
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
